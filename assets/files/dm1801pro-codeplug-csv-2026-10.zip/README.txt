ON3VZ codeplug for the Baofeng DM-1801 Pro (CPS V1.60), Belgium, FM + DMR (BrandMeister)
State: 29 October 2026. Exported from my own CPS after all manual corrections.

Import order in the CPS: talkgroups.csv (Digital > Talk Groups), rx_group.csv (Digital > RX Group List),
channel.csv (Public > Channel), scan.csv (Public > Scan), zone.csv (Public > Zone),
roaming_channel.csv (Public > Roaming Channel), roaming_zone.csv (Public > Roaming Zone).

Before you use it:
- Set your own DMR ID in Digital > DMR ID and name that entry exactly as in the DMR ID column of channel.csv (here "ON3VZ"), or change that column.
- Repeater data changes. Check every repeater you use against BrandMeister, RepeaterBook, ON0.be or the owner.
- CTCSS decode is deliberately None on all FM channels; encode tones are set.
- Known CPS quirks: the Scan List column of channel.csv is ignored on import (link channels by hand),
  scan.csv loses names and settings (enter them in Scan Information), a roaming zone holds max 16 channels.
- Only transmit where your licence allows it. ON3 (class C) licences are valid in Belgium only.
Full explanation: https://on3vz.github.io/blog/
